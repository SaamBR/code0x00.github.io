<?php
ob_start();
session_start();
if (!isset($_SESSION['usuario0x00']) && (!isset($_SESSION['senha0x00']))){ // !isset - Se não existir a sessão, direcione para index.php
    header('Location: index.php'); exit;
}
include ('lib/conexao.php');
include ('lib/logout.php');
?>

<!DOCTYPE html>
	<html lang="pt-br">
	<head>
	    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="description" content="the best code br desenvolvimento web">
    <meta name="keywords" content="palavrachave, palavra-chave, code, dicas, tutoriais, curso, python, html, apostilas, web, css, php, ">
    <meta name="author" content="Saam Souza BR">
    <meta name="robots" content="index,follow">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=PT+Serif" rel="stylesheet">
    <script rel="text/javascript" src="js/timer.js"></script>
    <script rel="text/javascript" src="js/block-page.js"></script> 
    <link rel="stylesheet" href="css/livros-de-seguranca.css">
    <title>Darkcode0x00 - Livros de segurança</title>

      <style type="text/css">
        /*Remove botão de download de vídeos*/
        video::-internal-media-controls-download-button {
        display:none;
        }

        video::-webkit-media-controls-enclosure {
         overflow:hidden;
        }

        video::-webkit-media-controls-panel {
        width: calc(100% + 30px); /* Adjust as needed */
        }
      </style>
		
	</head>

   <body onload='timer();' onkeydown='return validateKey(event)' onselectstart='return false' oncontextmenu='return false' ondragstart='return false'>

    <input type="checkbox" id="menu-toggle">
      <nav class="menu">
          <ul>
            <li class="li_hover"><a href="index.php" target="_selfie">HOME</a></li>
            <li class="li_hover"><a href="sobre.php" target="_selfie">SOBRE</a></li>
            <li class="li_hover"><a href="aviso.php" target="_selfie">AVISO</a></li>
            <li class="li_hover"><a href="livros-de-seguranca.php" target="_selfie">LIVROS DE SEGURANÇA</a></li>
            <li class="li_hover"><a href="ferramentas-tools.php" target="_selfie">FERRAMENTAS(TOOLS)</a></li>
            <li class="li_hover"><a href="pedidos-de-post.php" target="_selfie">PEDIDOS DE POST</a></li>
            <li class="li_hover"><a href="code.php" target="_selfie">CODE</a></li>  
            <li class="li_hover"><a href="#" title="nossos cursos">CURSOS</a>
              <ul>
                <li class="li_hover"><a href="curso-de-logica.php" target="_selfie">CURSO DE LÓGICA</a></li>
                <li class="li_hover"><a href="curso-de-python.php" target="_selfie">CURSO DE PYTHON 3.7</a></li>
                <li class="li_hover"><a href="curso-de-web.php" target="_selfie">CURSO DE WEB </a></li>
                <li class="li_hover"><a href="curso-de-linguagem-c.php" target="_selfie">CURSO DE C</a></li>
                <li class="li_hover"><a href="#" title="fechar menu"><label for="menu-toggle" id="fechar_menu">FECHAR MENU</label></a></li>
              </ul>
            </li>     
          </ul>
        </nav>

      <div class="include-tudo">
      <div class="header-top-principal">
        <header id="header1"> <!-- Cabeçalho principal fixo-->
          <label for="menu-toggle" class="bars">&#8801;</label>
          <div id="titulo"><h1>Darkcode 0x00</h1></div>
        </header>  <!-- Fim do header1 --> 
      </div> <!-- Fim da div header-top-principal -->

      <div class="header-top-fixo">
        <header id="header2"> <!-- Cabeçalho secundário fixo -->
          <img src="img/gotohacker.gif" alt="wallpaper" id="wallpaper-gif">
        </header>
      </div><!-- Fim da div header-top-fixo -->

      <div class="banner-video">
        <div id="video-intro" class="animar">
          <video width="560" oncontextmenu="return false;" controls poster="img/wallpaper.gif" id="intro">
            <source src="video/banner-video-intro.mp4"/>
              <p>Seu browser não é compatível com a tag video</p>
          </video>
        </div>

        <div id="painel-logout" class="animar"> 
            <div id="hackfig"> 
              <img src="img/hacking.gif" alt="hacking gif" id="hackgif">
            </div>
            <?php
            print "<span>Online: " . $_SESSION['usuario0x00'] . "</span></br>";
            ;?>
            <a href='?Sair' class='efeitologout'>Logout</a><br/>
        </div>
    </div><!--Fim da div banner video-->
        
      <div class="tudo"><!-- Div position relative - Envolve todo o conteúdo da página após os divs fixed -->

        <div class="conteudo-main">
          <section class="barraEsquerda">
          	<article>
  					  <h1>Livros de segurança</h1>
  					</article>
          </section>

  				<aside class="barraDireita">

          <article class="widget">
            <header><h1 style="border-bottom: 2px solid #289dcc; font-size: 1.6em">Widget Em Destaque</h1></header>
              <p class="txt">Os principais assuntos relacionados, a notícias e entretenimentos do mundo, você encontra aqui.</p>
              <p class="txt">Veja também alguns dos destaques do tecmundo,
              no link abaixo.</p>
              <ul class="txt">
                <li><a href="#tecmundo">Tecmundo - Destaques</a></li>
              </ul>
          </article>

          <article class="widget">
            <div class="feeds">
              <header><h2>Visite nosso canal no youtube</h2></header>
                <img src="img/gif/seta-vertical"alt="Seta vertical" class="unnamed-gif-img">
                <ul>
                  <li><a href="https://www.youtube.com/channel/UCOTkZBcJdOlfEiNHpOnzzyQ" target="_blank"><img src="img/gif/subscribe.gif" alt="Subscribe" class="unnamed-gif-img"></a></li>
                </ul>
            </div>

            <div class="feeds">
              <h3 class="txt">Links relacionados</h3>
                <h4 class="txt">Professor Darkcode keep in mind programming</h4>
              <p class="txt">Se increva no canal principal Professor Darkcode.</p>
              <ul>
                <li><a href="https://www.youtube.com/channel/UCj7Co_FKTnGcZtbZb_ts52g" target="_blank"><img src="img/gif/youtube.gif" alt="Youtube gif" class="unnamed-gif-img"></a></li>
              </ul>
            </div>
          </article>  

          <article class="widget">    
            <header><h2>Entretenimentos</h2></header>
              <iframe src="https://feed.mikle.com/widget/v2/62176/" height="402px" width="100%" class="fw-iframe" scrolling="no" frameborder="0"></iframe> 
          </article>
            
          <article class="widget">
            <a name="tecmundo"></a>
            <header><h2>Notícias</h2></header>
            <iframe src="https://feed.mikle.com/widget/v2/62155/" height="420px" width="100%" class="fw-iframe" scrolling="no" frameborder="0"></iframe> 
          </article>

          <article class="widget">
            <div class="feeds">
              <header><h2>Google Maps</h2></header>
              <h3 class="txt">Onde estamos</h3>
              <iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d14671.526305810798!2d-50.643066049999995!3d-23.1745219!3m2!1i1024!2i768!4f13.1!5e0!3m2!1spt-PT!2sbr!4v1516731912625" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>

            <div class="feeds">
              <h2 class="txt">Links relacionados</h2>
              <h3 class="txt">Sobre o Google</h3>
              <p class="txt">Google LLC é uma empresa multinacional de serviços online e software dos Estados Unidos. O Google hospeda e desenvolve uma série de serviços e produtos baseados na internet, e gera lucro principalmente através da publicidade pelo AdWords.</p><br/>
              <ul class="txt">
                <li><a href="https://www.google.com.br/url?sa=t&rct=j&q=&esrc=s&source=web&cd=14&cad=rja&uact=8&ved=0ahUKEwjW9oOm4O7YAhXMh5AKHc6uAJYQmhMIkQEwDQ&url=https%3A%2F%2Fpt.wikipedia.org%2Fwiki%2FGoogle&usg=AOvVaw31YDGZonj5fMDHyhEpczQU" target="_blank">Wikipédia</a></li>
                <li><a href="https://www.google.com" target="_blank">Google</a></li>
                <li><a href="https://translate.google.com.br/?hl=pt-BR" target="_blank">Google Tradutor</a></li>
              </ul>
            </div>
          </article>

          <article class="widget">
            <header><h2>Apostilas</h2></header>
            <p class="txt">Script Brasil: O maior portal em língua portuguesa.</p>
            <ul class="txt">
              <li><a href="https://www.scriptbrasil.com.br" target="_blank">Script Brasil - Apostilas</a></li>
            </ul><br/>
          
            <p class="txt">Apostilando: Milhares de Apostilas Grátis.</p>
            <ul class="txt">
              <li><a href="https://www.apostilando.com" target="_blank">Ir para o site do apostilando</a></li>
            </ul>
          </article>
        </aside>
      </div><!--Fim do conteudo-main-->

      <section class="anime">
          <div class="animar" id="cropped">
            <img src="img/cropped-black.jpg" alt="Programming jpg" id="img-cropped">
          </div>
        </section>
        
        <section class="anime">
          <div class="animar" id="timer-user-online">
            <div id="timer"></div>
              <script id="_wauu2p">var _wau = _wau || []; _wau.push(["small", "7q3yvcep2r", "u2p"]);</script><script async src="//waust.at/small.js">
              </script>
          </div>
        </section>

        <footer class="fix-absolute-footer"> <!--Classe opcinal caso precise -->
	        <div class="-rodape">
	          
	          <div id="youtube">
	          <p class="color-letter-rp">Visite nosso canal no youtube:<a href="https://www.youtube.com/channel/UCj7Co_FKTnGcZtbZb_ts52g" target="_blank"><img src="img/2018_social_media_popular_app_logo_youtube-128.png" class="redes-sociais-rp"></a></p>
	          </div>
	                
	          <div id="twitter">
	          <p class="color-letter-rp">Siga-nos no twitter:<a href="https://twitter.com/Darkcode0x00" target="_blank"><img src="img/2018_social_media_popular_app_logo_twitter-128.png" class="redes-sociais-rp"></a></p>
	          </div>
	                
	          <div id="facebook">
	          <p class="color-letter-rp">Nosso facebook:<a href="https://www.facebook.com/darckode0x00" target="_blank"><img src="img/2018_social_media_popular_app_logo_facebook-128.png" class="redes-sociais-rp"></a></p>
	          </div>

	           <div><a href="#" class="color-letter-rp"><i class="fa fa-chevron-up" aria-hidden="true"></i></a></div>
	                
	          <p class="color-letter-rp">&copy 2017 DARKCODE 0X00. Todos os direitos reservados.</p>
	          <p class="color-letter-rp">Powered by Saam Souza BR - Contato: contato-souzabr@thebestcodebr.com</p>
	          

	        </div>  
        </footer>
      </div><!--Fim da div position relative -->
      <!-- Jquery.js aqui em conjunto com anime.js para ativar função de slide-->
    <script rel="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <script rel="text/javascript" src="js/anime.js"></script>
    </div><!--include tudo fim -->
    </body>
  </html> <!-- Fim do corpo da página -->    


  							
  						   
  						
  						
  		
