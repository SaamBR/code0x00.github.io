<?php
ob_start();
session_start();
if (isset($_SESSION['usuario0x00']) && (isset($_SESSION['senha0x00']))){ // !isset - Se não existir a sessão, direcione para index.php
    header('Location: home.php'); exit; // ?Comando acesso negado
}
include ('lib/conexao.php');

?>

<!DOCTYPE html>
	<html lang="pt-br">
		<head>
		    
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="utf-8">
		<meta name="description" content="Darkcode0x00 - Aqui você irá encontrar cursos, artigos e tutoriais voltados para todas as áreas sobre linguagem de programação">
        <meta name="keywords" content="palavrachave, palavra-chave, code, dicas, tutoriais, curso, python, html, apostilas, web, css, php, ">
        <meta name="author" content="Saam Souza BR">
        <meta name="robots" content="index,follow">
		<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	    <link href="https://fonts.googleapis.com/css?family=PT+Serif" rel="stylesheet">
	    <script type="text/javascript" src="js/timer.js"></script>
	    <script type="text/javascript" src="js/block-page.js"></script> 
		<link rel="stylesheet" href="css/rodape.css">
		<link rel="stylesheet" href="css/login-cadastro.css">
		<title>Darkcode0x00 - Aqui você irá encontrar cursos, artigos e tutoriais voltados para todas as áreas sobre linguagem de programação</title>
		
		<style type="text/css">
        /*Remove botão de download de vídeos*/
        video::-internal-media-controls-download-button {
        display:none;
        }

        video::-webkit-media-controls-enclosure {
         overflow:hidden;
        }

        video::-webkit-media-controls-panel {
        width: calc(100% + 30px); /* Adjust as needed */
        }
      </style>
      
      <!-- Aqui vai o script que mostrar mensagem acesso negado-->
                <?php
                if(isset($_GET['acao'])){
                    
                    if(!isset($_POST['logar'])){
                    
                        $acao = $_GET['acao'];
                        if($acao == 'negado'){
                            echo "<div style='margin:0 auto;display:flex; flex-wrap:wrap; width:1024px; max-width:100%;heitght:auto;background-color:#000; color:#fff; font-size:1em; justify-content:center; align-items:center'>Tente novamente mais tarde!</div>";
                            header('Refresh:2, index.php');
                        // Exibir mensagem de acesso negado
                        
                        }
                    }
                
                }
                ?>
                <!--Aqui termina-->
           
      
		</head>
		<body onload='timer();' onkeydown='return validateKey(event)' onselectstart='return false' oncontextmenu='return false' ondragstart='return false'>
  	
		    <header>
            <nav class="animar">
                <div class="banner-video anime">
                <div id="video-intro" class="animar">
                    <video width="100%" oncontextmenu="return false;" controls  poster="img/wallpaper.gif" id="intro">
                        <source src="video/banner-video-intro.mp4"/>
                        <p>Seu browser não é compatível com a tag video</p>
                    </video>
                </div>
            </div><!--Fim da div banner video-->
                
            </nav>
            </header>
        
            
            <section class="login-cadastro animar">
                
                <section class="content-darkcode0x00-cadastro">
                    <section class="section-exibir-ip-facebook">
                        <section class="exibe-users-cadastrados">
                            <?php echo "<p style='color:#000;font-weight:bold'>Olá visitante, o seu ip atual é:</p>" .$_SERVER["REMOTE_ADDR"];?>
                        </section>
                    </section>
                    <h3 id="titulo-l-c">CADASTRAR</h3>
    		        <form action="lib/cadastrar.php" method="post" enctype="multpart/form-data">
        				<label for="name">Nome: </label>
                        <input type="text" name="name" id="name" placeholder="Nome" required/>
                        <label for="email">Email: </label>
                        <input type="text" name="email" id="email" placeholder="Email" required/>
                        <label for="username">Usuário: </label>
                        <input type="text" name="username" id="username" placeholder="Usuário" required/>
                        <label for="password">Senha: </label>
                        <input type="password" name="password" id="password" placeholder="Senha" required/>
        				<input class="btn" type="submit" name="cadastrar" value="Cadastrar">
        	        </form>
    		    </section> <!-- Fim da tela de cadastro -->
                
                <section class="content-darkcode0x00-login">
                    <!-- Código do php do formulário de login aqui-->
                
                    <h3 id="titulo-l-c">LOGIN</h3>
                    <form  action="lib/logar.php" method="post">
                        <label for="username">Usuário: </label>
                        <input type="text" name="username" id="username" placeholder="Usuário" required/>
                        <label for="password">Senha: </label>
                        <input type="password" name="password" id="password" placeholder="Senha" required/>
					    <input class="btn" type="submit" name="logar" value="Entrar">
					</form>
					
					<a href="lib/lembrar.php">Esqueceu sua senha?</a>
					
				<!--<section class="section-exibir-ip-facebook">
                    <section class="content-darkcode0x00-facebook-login">
                        <!-- Botão login do facebook-->
                        <!--<h3 id="titulo-l-c-facebook">Entrar com Facebook</h3>
                      
                        <div id="status"></div>
                    </section>-->
                </section>
                </section>
            </section>
            
            
            
            <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
            <script type="text/javascript" src="js/anime.js"></script>
            
            <footer class="fix-absolute-footer"> <!--Classe opcinal caso precise -->
	        <div class="-rodape">
	          
	          <div id="youtube">
	          <p class="color-letter-rp">Visite nosso canal no youtube:<a href="https://www.youtube.com/channel/UCj7Co_FKTnGcZtbZb_ts52g" target="_blank"><img src="img/2018_social_media_popular_app_logo_youtube-128.png" class="redes-sociais-rp"></a></p>
	          </div>
	                
	          <div id="twitter">
	          <p class="color-letter-rp">Siga-nos no twitter:<a href="https://twitter.com/Darkcode0x00" target="_blank"><img src="img/2018_social_media_popular_app_logo_twitter-128.png" class="redes-sociais-rp"></a></p>
	          </div>
	                
	          <div id="facebook">
	          <p class="color-letter-rp">Nosso facebook:<a href="https://www.facebook.com/darckode0x00" target="_blank"><img src="img/2018_social_media_popular_app_logo_facebook-128.png" class="redes-sociais-rp"></a></p>
	          </div>

	          <div><a href="#" class="color-letter-rp"><i class="fa fa-chevron-up" aria-hidden="true"></i></a></div>
	                
	          <p class="color-letter-rp">&copy 2018 DARKCODE 0X00. Todos os direitos reservados.</p>
	          <p class="color-letter-rp">Powered by Saam Souza BR - Contato: saam@thebestcodebr.com</p>
	          

	        </div>  
        </footer>
        
		</body>
		</html>
		
	