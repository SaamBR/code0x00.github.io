function validateKey (evt)
if (evt.keyCode == '17')
{alert("Comando Desativado")
return false}
return true}
        
function bloquear(e){return false}
function desbloquear(){return true}
document.onselectstart=new Function ("return false")
if (window.sidebar){document.onmousedown=bloquear
document.onclick=desbloquear}
        