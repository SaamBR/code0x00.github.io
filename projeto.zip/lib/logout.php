<?php

if (isset($_REQUEST['Sair'])){
   session_destroy;
   session_unset($_SESSION['usuario0x00']);
    session_unset($_SESSION['senha0x00']);
    header('Location: index.php');
}

?>