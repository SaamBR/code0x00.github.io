<!DOCTYPE html>
	<html lang="pt-br">
		<head>
		    <meta charset="uft-8">
		</head>
        <body>
            <?php  
            include 'conexao.php';
            header('Content-Type: text/html; charset=UTF-8');
            
                if(isset($_POST['recuperar'])){
            	$email = utf8_decode (strip_tags(addslashes(trim($_POST['email']))));
            	
            	$selecionar = "SELECT * FROM users WHERE email='$email'";
            	
                try{
                    $resultado = $conexao->prepare($selecionar);        
                   // $resultado->bindParam(':email', $email, PDO::PARAM_STR);
                    $resultado->execute();
                    $contar_registro_do_banco = $resultado->rowCount();
                    
                    if($contar_registro_do_banco >0){
                        
                    foreach($conexao->query($selecionar) as $exibir);
                    
                    //Criar variáveis e pegar nomes da tabela de usuários cadastrados
                    $nameUser = $exibir['name'];
                    $usernameUser = $exibir['username'];
                    $emailUser = $exibir['email'];
                    $passwordUser = $exibir['password'];
                    
                    require_once ('envia-email/PHPMailer/class.phpmailer.php');
            		
                	$Email = new PHPMailer();
                	$Email->SetLanguage("br");
                	$Email->IsSMTP(); // Habilita o SMTP 
                	$Email->SMTPAuth = true; //Ativa e-mail autenticado
                	$Email->Host = 'mail.thebestcodebr.com'; // Servidor de envio # verificar qual o host correto com a hospedagem as vezes fica como smtp.
                	$Email->Port = '587'; // Porta de envio
                	$Email->Username = 'saam@thebestcodebr.com'; //e-mail que será autenticado
                	$Email->Password = '.r0uter.'; // senha do email
                	// ativa o envio de e-mails em HTML, se false, desativa.
                	$Email->IsHTML(true); 
                	// email do remetente da mensagem
                	$Email->From = 'saam@thebestcodebr.com';
                	// nome do remetente do email
                	$Email->FromName = utf8_decode($email);
                	// Endereço de destino do emaail, ou seja, pra onde você quer que a mensagem do formulário vá?
                	$Email->AddReplyTo($email, $nameUser);
                	$Email->AddAddress ($email); // para quem será enviada a mensagem
                	// informando no email, o assunto da mensagem
                	$Email->Subject = '(Contato do site - darkcode0x00)';
                	// Define o texto da mensagem (aceita HTML)
                	$Email->Body .= "Siga os dados para obter o acesso novamente<br /><br />
                						 <strong>Nome:</strong> $nameUser<br />
                						 <strong>E-mail:</strong> $emailUser<br />
                						 <strong>Usuário:</strong> $usernameUser<br />
                						 <strong>Senha:</strong> $passwordUser<br /><br />
                						 <strong>Obs: Você não precisa responder a esse e-mail.</strong><br />";
            		// verifica se está tudo ok com oa parametros acima, se nao, avisa do erro. Se sim, envia.
            		
            		if(!$Email->Send()){
            			echo "<p>A mensagem não foi enviada. </p>";
            			echo "Erro: " . $Email->ErrorInfo;
            		}else{
            			echo "Suas informações para acesso,<br /> foram enviadas para seu e-mail.";
            			header ('Refresh:2, lembrar.php');
            			
            		}
                    
                    }else{
                        echo "<div style='margin:0 auto;display:flex; flex-wrap:wrap; width:1024px; max-width:100%;heitght:auto;background-color:#000; color:#fff; font-size:1em; justify-content:center; align-items:center'>Erro ao recuperar.<br />
                        O e-mail digitado não existe em nosso sistema!</div>";
                        header ('Refresh:2, ../index.php');
                    }
                    
                    }catch(PDOException $e){
                    echo $e;
                    
                    }
                }//Se clicar no botão recuperar
            ?>
        </body>
    </html>