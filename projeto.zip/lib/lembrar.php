<?php
include 'conexao.php';
?>

<!DOCTYPE html>
	<html lang="pt-br">
		<head>
		    
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="utf-8">
		<meta name="description" content="Darkcode0x00 - Aqui você irá encontrar cursos, artigos e tutoriais voltados para todas as áreas sobre linguagem de programação">
        <meta name="keywords" content="palavrachave, palavra-chave, code, dicas, tutoriais, curso, python, html, apostilas, web, css, php, ">
        <meta name="author" content="Saam Souza BR, saam@thebestcodebr.com">
        <meta name="robots" content="index,follow">
		<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	    <link href="https://fonts.googleapis.com/css?family=PT+Serif" rel="stylesheet">
	    <script type="text/javascript" src="js/block-page.js"></script> 
		<link rel="stylesheet" href="../css/rodape.css">
		<link rel="stylesheet" href="../css/login-cadastro.css">
		<title>Darkcode0x00 - Aqui você irá encontrar cursos, artigos e tutoriais voltados para todas as áreas sobre linguagem de programação</title>
		
		</head>
		
		<body onload='timer();' onkeydown='return validateKey(event)' onselectstart='return false' oncontextmenu='return false' ondragstart='return false'>
		    
		    <header>
            <nav class="animar">
      
		    </nav>
            </header>
                <section class="content-darkcode0x00-recuperar-senha  redefinir-senha">
                    <form action='redefinir.php' method='post'>
                        <h3 id="titulo-l-c">RECUPERAR SENHA</h3>
                        <label for='email'>Email Address:</label>
                        <input type='text' name='email' id='email' placeholder="Email" required/>
					    <input class='btn' type='submit' name='recuperar' id='recuperar' value='Recuperar senha'>
					</form>
					<h5 id="titulo-l-c">Deseja logar-se?</h5> <a href="../index.php" target="_self">FAZER LOGIN</a>
            </section>
            
            <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
            <script type="text/javascript" src="js/anime.js"></script>
        
		</body>
		</html>
		