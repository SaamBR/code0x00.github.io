
<!DOCTYPE html>
	<html lang="pt-br">
	<head>
	    <meta charset="utf-8">
	</head>
	<body>

        <?php
            //Responsável pela conexão com o bando de dados
            try{
                $conexao = new PDO('mysql:host=localhost;dbname=thebestc_db', 'thebestc_root', 'Msql_.8119.');
                $conexao -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            }catch(PDOException $e){ 
                echo 'ERROR'. $e ->getMessage();
            }
            
            
            $h = $_GET['h'];
            
            if(!empty($h)){
                $conexao->query("UPDATE users SET status = '1' WHERE (id) = '$h'");
                echo "Cadastro confirmado com sucesso";
                echo "<a href='https://thebestcodebr.com'/> Clique aqui para ir para a página de login</a>";
                exit;
            }
     
        ?>
    </body>
    </html>