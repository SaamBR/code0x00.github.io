<?php
//Responsável pela conexão com o bando de dados

try{
    $conexao = new PDO('mysql:host=localhost;dbname=thebestc_db', 'thebestc_root', 'Msql_.8119.');
    $conexao-> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}catch(PDOException $e){ 
    echo 'ERROR'. $e ->getMessage();
}
?>