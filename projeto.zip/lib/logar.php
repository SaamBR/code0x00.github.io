<?php
ob_start();
session_start();
if (isset($_SESSION['usuario0x00']) && (isset($_SESSION['senha0x00']))){
    header('Location: ../home.php'); exit;
}

include ('conexao.php');

if(isset($_POST['logar'])){
    //recuperar dados
    $c_username = (trim(strip_tags($_POST['username'])));  //Insere barra invertida evitando sql injection no campo username
    $c_password = (trim(strip_tags($_POST['password'])));
    //selecionar os dados do banco de dados
    
    //Evita códigos sql injection type = 'or'1=1;# por exemplo
    //$c_username = preg_replace('/[^[:alnum:]_.-]/','',$c_username);
    //Insere barra invertida evitando sql injection no campo senha
    
    $selecionar = "SELECT * FROM users WHERE status= '1' AND BINARY username= :username AND BINARY password= :password"; //COMANDO BINARY DIFERENCIA CASE SENSITIVE
    
    try{
        $resultado = $conexao->prepare($selecionar);//Prepara a conexao com o bando de dados
        $resultado->bindParam(':username', $c_username, PDO::PARAM_STR);
        $resultado->bindParam(':password', $c_password, PDO::PARAM_STR);
        $resultado->execute();
        $contar_registro_do_banco = $resultado->rowCount();//Conta o registro no banco de dados e exibi resultado
        
        if($contar_registro_do_banco >0){
            $c_username = ($_POST['username']);
            $c_password = ($_POST['password']);
            // Sessão para logar usuário
            $_SESSION['usuario0x00'] = $c_username;
            $_SESSION['senha0x00'] = $c_password;
            echo "<div style='margin:0 auto;display:flex; flex-wrap:wrap; width:1024px; max-width:100%;heitght:auto;background-color:#000; color:#fff; font-size:1em; justify-content:center; align-items:center'>Redirecionando para home!</div>";
            header('Refresh: 3, ../home.php');exit;
        
        }else{
            echo "<div style='margin:0 auto;display:flex; flex-wrap:wrap; width:1024px; max-width:100%;heitght:auto;background-color:#000; color:#fff; font-size:1em; justify-content:center; align-items:center'>Dados incorretos.<br /> Digite suas credenciais novamente!</div>";
            header('Refresh: 2, ../index.php');
        }
        
        }catch(PDOException $e){
        echo $e;
        
        }
}// Se clicar no botão entrar no sistema
?>