

<!DOCTYPE html>
	<html lang="pt-br">
	<head>
	    <meta charset="utf-8">
	</head>
	<body>
	    <?php
            include ('conexao.php');
            if(isset($_POST['cadastrar'])){ //inicia a inserção dos dados no banco de dados
                $c_name = (trim(strip_tags($_POST['name'])));
                $c_email = (trim(strip_tags($_POST['email'])));
                $c_username = (trim(strip_tags($_POST['username'])));
                $c_password = (trim(strip_tags($_POST['password'])));
                $ip = $_SERVER['REMOTE_ADDR']; //PEGA IP E SALVA NO BANCO
                
                //INSERIR DADOS NO BANDO
                
                $inserir= "INSERT INTO users (name, email, username, password, ip) VALUES (:name, :email, :username, :password, :ip)";
                
                try{
                    $obter_dados = $conexao->prepare($inserir);//Prepara a conexao com a variável stmt e protege ataques sql-injection
                    $obter_dados->bindParam(':name', $c_name, PDO::PARAM_STR);
                    $obter_dados->bindParam(':email', $c_email, PDO::PARAM_STR);
                    $obter_dados->bindParam(':username', $c_username, PDO::PARAM_STR);
                    $obter_dados->bindParam(':password', $c_password, PDO::PARAM_STR);
                    $obter_dados->bindParam(':ip', $ip, PDO::PARAM_STR);
                    $obter_dados->execute();
                    $inserir_registro_no_banco = $obter_dados->rowCount();
                    
                     //Enviar email para confirmar cadastro
                        
                        $id = $conexao->lastInsertId();
                        $assunto = "Confirme seu cadastro";
                        $link = "https://thebestcodebr.com/lib/confirmarcadastro.php?h=". $id;
                        $mensagem = "Clique para confirmar seu cadastro " .$link;
                        $headers = "To: $c_username <$c_email>" . "\r\n";
                        $headers = "From: Saam Souza BR <saam@thebestcodebr.com>" . "\r\n";
                        
                        mail($c_email, $assunto, $mensagem, $headers);
                    
                    if($inserir_registro_no_banco >0){
                        
                        echo "<div style='margin:0 auto;display:flex; flex-wrap:wrap; width:1024px; max-width:100%;heitght:auto;background-color:#000; color:#fff; font-size:1em; justify-content:center; align-items:center'>Enviamos um e-mail para que você possa confirmar seu cadastro!</div>";
                        header('Refresh:3, ../index.php');
                
                    }else{
                        echo "<div style='margin:0 auto;display:flex; flex-wrap:wrap; width:1024px; max-width:100%;heitght:auto;background-color:#000; color:#fff; font-size:1em; justify-content:center; align-items:center'>Dados incorretos.<br /> Digite suas credenciais novamente!</div>";
                        header('Refresh:2, ../index.php');
                       exit;
                    }
                    
                    }catch(PDOException $e){
                    $e;
                    }
            }//Se clicar no botão cadastrar
                       
            ?>
	</body>
	</html>